package com.msbills;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsBillsApplicationTests {

    @Test
    void contextLoads() {
    }

}

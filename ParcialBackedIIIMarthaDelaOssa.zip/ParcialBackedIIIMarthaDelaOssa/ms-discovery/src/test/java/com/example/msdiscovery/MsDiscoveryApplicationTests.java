package com.example.msdiscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
